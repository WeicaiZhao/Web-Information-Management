There are two parts of the project, named partone and parttwo
1. First of all, please use the console or terminal to get the partone folder
2. install the npm first:    npm i
3. start it:    npm start
   Result:
   server run Url : http://localhost:3000
   Connected to the SQlite database.
4. So the database sqlite is prepared
5. run another console or terminal to get parttwo folder
6. install the npm:     npm i
7. start the server:    npm run serve
   Result:
   App running at:
     - Local:   http://localhost:8080/
     - Network: http://192.168.2.16:8080/
8. Open the browser and input http://localhost:8080/ you will get into the login page.
   Please register first.
9. There are two roles to choose: admin and normal
10. Click "Create new table", you can create and edit spreadsheet there.
11. There are two status, hide and share. share means can be copied.
12. After inputting the information, click Add, the data will be saved into the database.
13. When click Export CSV, although there are some chinese words there, it works.
    1. input the file name into the first row
    2. select the data type you wanna export
    3. click the blue button "导出"， the CSV file will be exported;
       click the white button "打印"， the file will be printed.
14. Click "Draw pie", the pie chart of data will be shown under the form. It analyzes the age distribution of the data.
15. click "Draw Line", the histogram of data will be shown under the pie chart.
16. After inputting all the data, click "Add" to save, and you can still "edit title", "edit excel", or "delete excel".